# Change Log

## [Unreleased]

## [0.3.2] - 2016-11-25

## Added

- Optimalize code
- Add getValue() function
- Add events

## Fixed

- Usage text in README.md

## [0.3.1] - 2016-11-18

## Added

- Add setDisable() and setEnable() function
- Add isDisable option
- Changelog file
- Beautify in files

## Fixed

- Remove and fix .DS_Store
- Remove bump version (inconsistent)
- First interaction show bad effect (negativ outside)
    - Solved max-width
- Version numbers (on May 16 add 3.0 -> bower registered)
