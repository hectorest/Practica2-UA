$(document).ready(function() {

    $("#radios").radiosToSlider();

});
